import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
//import { phoneNumberValidator } from '../../validators/phone-validator'
 import { phoneNumberValidator } from '../../services/phone-validator.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-add2',
  templateUrl: './user-add2.component.html',
  styleUrls: ['./user-add2.component.css']
})
export class UserAdd2Component implements OnInit {
  submitted = false;
  countries = ['', 'INDIA', 'USA', 'Germany', 'Italy', 'France'];
  contactForm:FormGroup;

  constructor(private userService: UserService) {
    this.contactForm = this.createFormGroup();
  }

  ngOnInit() {
  }

  createFormGroup() {
    return new FormGroup({
      email:   new FormControl('', [Validators.required, Validators.email]),
      mobile:  new FormControl('', [Validators.required, phoneNumberValidator]),
      //mobile:  new FormControl('', [Validators.required]),
      country: new FormControl('', [Validators.required])
    });
  }

  get mobile() {
    return this.contactForm.get('mobile');
  }

  get email() {
    return this.contactForm.get('email');
  }

  get country() {
    return this.contactForm.get('country');
  }

  onReset() {
    this.contactForm.reset();
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if(this.contactForm.invalid) {
      return;
    }

    // display form values on success
    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.contactForm.value, null, 4));

    var body = "user_name=" + this.contactForm.value.country 
        + "&email_id=" + this.contactForm.value.email
        + "&pass_word=" + this.contactForm.value.mobile;
    //alert('SUCCESS\n' + body);
	
    this.userService.createUser(body)
      .subscribe( data => {
        //this.router.navigate(['user-list']);
      });

  }

}
