import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-reactive-form2',
  template: `
    <p>reactive-form2 works!</p>
    <p>Value: {{ favoriteColorControl.value }}</p>
    Favorite Color: <input type="text" [formControl]="favoriteColorControl"><br><br>
    <button [ngClass]="'btn btn-success'" (click)="updateValue()">Replace the text with default color</button>
    
  `,
  styles: []
})
export class ReactiveForm2Component {

  favoriteColorControl = new FormControl('Red');

  updateValue() {
    this.favoriteColorControl.setValue('Black');
  }
}
