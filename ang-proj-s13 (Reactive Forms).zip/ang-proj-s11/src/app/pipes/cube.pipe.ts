import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cube'
})
export class CubePipe implements PipeTransform {

  // {{4 | cube}}
  // you will get 64
  transform(inputValue:number, ...args:unknown[]): number {
    return inputValue * inputValue * inputValue;
  }

}
