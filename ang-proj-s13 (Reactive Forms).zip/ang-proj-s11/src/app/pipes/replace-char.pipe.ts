import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'replaceChar'
})
export class ReplaceCharPipe implements PipeTransform {

  // {{"One Two Three Four" | replaceChar:"-"}}
  // you will get One-Two-Three-Four
  transform(input_value: string, seperator: string): string {//the last :string is return type
    return input_value.split(' ').join(seperator);
  }

}
