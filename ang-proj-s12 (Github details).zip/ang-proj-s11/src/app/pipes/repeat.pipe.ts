import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'repeat'
})
export class RepeatPipe implements PipeTransform {

  // {{"Syed" | repeat:4}}
  // you will get Syed Syed Syed Syed
  transform(word:string, times:number): string {
    let count = 1;
    let result = word;
    while(count < times) {
      result += ' ' + word;
      count++;
    }
    return result;
  }

}
