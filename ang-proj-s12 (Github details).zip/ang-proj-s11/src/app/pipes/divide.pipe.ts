import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'divide'
})
export class DividePipe implements PipeTransform {

  // {{100 | divide:20}}  
  // you will get 5
  transform(dividend:number, divisor:number): number {
    return dividend / divisor
  }

}
