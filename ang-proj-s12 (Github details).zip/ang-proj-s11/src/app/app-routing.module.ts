import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { UserAddComponent } from './components/user-add/user-add.component';
import { UserEditComponent } from './components/user-edit/user-edit.component';
import { DemoPipeComponent } from './components/demo-pipe/demo-pipe.component';
import { DemoDirective1Component } from './components/demo-directive1/demo-directive1.component';
import { ParentComponent } from './components/parent/parent.component';
import { ChildComponent } from './components/child/child.component';
import { GithubUserDetailComponent } from './components/github-user-detail/github-user-detail.component';
import { UserAdd2Component } from './components/user-add2/user-add2.component';


const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'contact', component:ContactUsComponent},
  {path:'about', component:AboutUsComponent},
  {path:'userlist', component:UserListComponent},
  {path:'useradd', component:UserAddComponent},
  {path:'useredit/:id',  component:UserEditComponent, pathMatch:'full'},
  {path:'built-in-pipes', component:DemoPipeComponent},
  {path:'demo-directive1', component:DemoDirective1Component},
  {path:'parent', component:ParentComponent},
  {path:'child', component:ChildComponent},
  {path:'github', component:GithubUserDetailComponent},
  {path:'reactive-form', component:UserAdd2Component},
  {path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
