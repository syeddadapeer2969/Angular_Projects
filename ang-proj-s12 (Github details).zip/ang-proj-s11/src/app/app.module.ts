import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule , ReactiveFormsModule  } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SiteLayoutComponent } from './components/site-layout/site-layout.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { UserAddComponent } from './components/user-add/user-add.component';
import { UserEditComponent } from './components/user-edit/user-edit.component';
import { DemoPipeComponent } from './components/demo-pipe/demo-pipe.component';
import { SqrtPipe } from './pipes/sqrt.pipe';
import { SquarePipe } from './pipes/square.pipe';
import { CubePipe } from './pipes/cube.pipe';
import { DividePipe } from './pipes/divide.pipe';
import { RepeatPipe } from './pipes/repeat.pipe';
import { ReplaceCharPipe } from './pipes/replace-char.pipe';
import { CompanyNameDirective } from './directives/company-name.directive';
import { DemoDirective1Component } from './components/demo-directive1/demo-directive1.component';
import { HighlightDirective } from './directives/highlight.directive';
import { ParentComponent } from './components/parent/parent.component';
import { ChildComponent } from './components/child/child.component';
import { GithubUserDetailComponent } from './components/github-user-detail/github-user-detail.component';
import { UserAdd2Component } from './components/user-add2/user-add2.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SiteLayoutComponent,
    HomePageComponent,
    ContactUsComponent,
    AboutUsComponent,
    PageNotFoundComponent,
    UserListComponent,
    UserAddComponent,
    UserEditComponent,
    DemoPipeComponent,
    SqrtPipe,
    SquarePipe,
    CubePipe,
    DividePipe,
    RepeatPipe,
    ReplaceCharPipe,
    CompanyNameDirective,
    DemoDirective1Component,
    HighlightDirective,
    ParentComponent,
    ChildComponent,
    GithubUserDetailComponent,
    UserAdd2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgxPaginationModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [SiteLayoutComponent]
})
export class AppModule { }
