import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  apiUrl:string = "http://localhost:5555/user/"

  constructor(private http: HttpClient) { }

  getUsers() {
    return this.http.get(this.apiUrl);
  }

  createUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }

  deleteUser(userid:any) {
    return this.http.delete(this.apiUrl + userid);
  }

  getUserById(userid:any) {
    return this.http.get<any>(this.apiUrl + userid);
  }

  updateUser(body: string, userid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.apiUrl + userid, body, {headers: headers, responseType:'text'});
  }

}
