import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  goldRate:number = 34000
  constructor() { }

  setRate(currentRate:number) {
    this.goldRate = currentRate
  }

  getRate() {
    return this.goldRate;
  }
}
