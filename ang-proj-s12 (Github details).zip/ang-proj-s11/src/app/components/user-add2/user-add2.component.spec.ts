import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAdd2Component } from './user-add2.component';

describe('UserAdd2Component', () => {
  let component: UserAdd2Component;
  let fixture: ComponentFixture<UserAdd2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserAdd2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAdd2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
