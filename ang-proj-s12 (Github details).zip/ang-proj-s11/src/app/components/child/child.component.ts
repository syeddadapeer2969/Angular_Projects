import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {

  @Input() counter_in_child:any

  constructor() {
    console.log('child constructor')
  }

  ngOnInit(): void {
    console.log('child ngOnInit')
  }

  ngOnChanges(): void {
    console.log('child ngOnChanges')
  }

  ngDoCheck(): void {
    console.log('child ngDoCheck')
  }

  ngAfterContentInit(): void {
    console.log('child ngAfterContentInit')
  }

  ngAfterContentChecked(): void {
    console.log('child ngAfterContentChecked')
  }

  ngAfterViewInit(): void {
    console.log('child ngAfterViewInit')
  }

  ngAfterViewChecked(): void {
    console.log('child ngAfterViewChecked')
  }

  ngOnDestroy(): void {
    console.log('child ngOnDestroy')
  }

}
