import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from "./../../services/user.service";
import {first} from "rxjs/operators";

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {

  id:any
  user_name:string = ''
  email_id:string = ''
  pass_word:string = ''
  message = ''

  constructor(private route: ActivatedRoute, private router: Router, private userService:UserService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    })
    this.userService.getUserById(this.id)
      .subscribe( data1 => {
        console.log(data1)
        this.user_name = data1.user_name;
        this.email_id  = data1.email_id;
        this.pass_word = data1.pass_word;
      },
      error => {
        alert(error);
      });
  }

  editUser() {
    var body = "id=" + this.id 
        + "&user_name=" + this.user_name 
        + "&email_id=" + this.email_id 
        + "&pass_word=" + this.pass_word;
    this.userService.updateUser(body, this.id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['userlist']);
        },
        error => {
          alert(error);
        });
  }

}
