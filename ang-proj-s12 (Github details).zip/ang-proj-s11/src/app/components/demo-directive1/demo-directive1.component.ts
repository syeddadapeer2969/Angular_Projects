import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-directive1',
  templateUrl: './demo-directive1.component.html',
  styleUrls: ['./demo-directive1.component.css']
})
export class DemoDirective1Component implements OnInit {

  color = ''
  constructor() { }

  ngOnInit(): void {
  }

}
