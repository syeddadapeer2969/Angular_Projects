import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCompanyName]'
})
export class CompanyNameDirective {
  constructor(Element: ElementRef) {
    console.log(Element);
    //Element.nativeElement.innerText="Amar Systems is printed by CompanyName Directive. ";
    Element.nativeElement.innerText = "Angular Training";
  }
}
