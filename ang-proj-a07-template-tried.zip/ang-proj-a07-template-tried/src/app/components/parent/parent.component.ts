import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  counter_value_at_parent:any// Should not be initialized
  constructor() { }

  ngOnInit(): void {
  }

  receive_from_child(value1:any) {
    this.counter_value_at_parent = value1
  }

}
