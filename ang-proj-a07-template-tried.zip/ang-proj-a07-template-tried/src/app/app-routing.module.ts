import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomePageComponent } from './components/home-page/home-page.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ParentComponent } from './components/parent/parent.component';
import { ChildComponent } from './components/child/child.component';
import { SwitchComponent } from './components/switch/switch.component';

const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'contact', component:ContactUsComponent},
  {path:'about', component:AboutUsComponent},
  {path:'parent', component:ParentComponent},
  {path:'child', component:ChildComponent},
  {path:'switch', component:SwitchComponent},
  {path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
