import { Directive1Directive } from './directive1.directive';

describe('Directive1Directive', () => {
  it('should create an instance', () => {
    const directive = new Directive1Directive();
    expect(directive).toBeTruthy();
  });
});
