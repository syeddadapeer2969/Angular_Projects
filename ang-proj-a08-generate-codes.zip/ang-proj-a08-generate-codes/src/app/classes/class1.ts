export class Class1 {
}
