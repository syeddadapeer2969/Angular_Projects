import { Class1 } from './class1';

describe('Class1', () => {
  it('should create an instance', () => {
    expect(new Class1()).toBeTruthy();
  });
});
