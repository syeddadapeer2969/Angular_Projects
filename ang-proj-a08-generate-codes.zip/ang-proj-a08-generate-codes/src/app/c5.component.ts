import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c5',
  template: `
    <p>
      c5 works!
    </p>
  `,
  styles: [
  ]
})
export class C5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
