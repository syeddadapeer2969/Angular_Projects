import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c2',
  template: `
    <p>c2 works!</p>
    <h1>c2 works!</h1>
    <button class="btn btn-success">Click</button>
  `,
  styleUrls: ['./c2.component.css']
})
export class C2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
