import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserListComponent } from './user-list/user-list.component';//.ts
import { UserAddComponent } from './user-add/user-add.component';

@NgModule({
  declarations: [// list all Components, Directives, Pipes
    AppComponent,
    UserListComponent,
    UserAddComponent
  ],
  imports: [// list all Modules
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],// list all Services
  bootstrap: [AppComponent]// First Component to load
})
export class AppModule { }
