import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-pipe',
  templateUrl: './demo-pipe.component.html',
  styleUrls: ['./demo-pipe.component.css']
})
export class DemoPipeComponent implements OnInit {

  title = 'aMar syStems';
  todaydate = new Date();  
  json_data = {name: 'Amar', age: '25', address:{place: 'Vadapalani', city: 'Chennai'}};  
  months = ['Jan', 'Feb', 'Mar', 'April', 'May', 'Jun', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  dividend = 24
  divisor = 6

  constructor() { }

  ngOnInit(): void {
  }

}
