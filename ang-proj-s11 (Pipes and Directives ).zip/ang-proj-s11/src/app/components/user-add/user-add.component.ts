import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { UserService } from "./../../services/user.service";

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent implements OnInit {

  id:any
  user_name:string = ''
  email_id:string = ''
  pass_word:string = ''
  message = ''

  constructor(private router:Router, private userService:UserService) { }// Dependency Injection

  ngOnInit(): void {
  }

  addUser = () => {
    var body = "user_name=" + this.user_name 
        + "&email_id=" + this.email_id 
        + "&pass_word=" + this.pass_word;
    this.userService.createUser(body)
      .subscribe( data => {
        this.router.navigate(['userlist']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
}
