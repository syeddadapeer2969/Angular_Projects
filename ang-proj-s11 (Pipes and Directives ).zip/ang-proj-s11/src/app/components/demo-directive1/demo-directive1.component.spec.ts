import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemoDirective1Component } from './demo-directive1.component';

describe('DemoDirective1Component', () => {
  let component: DemoDirective1Component;
  let fixture: ComponentFixture<DemoDirective1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DemoDirective1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DemoDirective1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
