import { Component, OnInit } from '@angular/core';
import { GithubService } from "./../../services/github.service";

@Component({
  selector: 'app-github-user-detail',
  templateUrl: './github-user-detail.component.html',
  styleUrls: ['./github-user-detail.component.css']
})
export class GithubUserDetailComponent implements OnInit {

  userId:string = ''
  result:any
  error_message:string = ''
  constructor(public githubService:GithubService) { }

  ngOnInit(): void {
  }

  fetchDataFromGitHub() {
    this.githubService.getUserInfo(this.userId).subscribe(response => this.result = response)
  }
}
