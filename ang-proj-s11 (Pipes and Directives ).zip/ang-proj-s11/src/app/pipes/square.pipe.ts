import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'square'
})
export class SquarePipe implements PipeTransform {

  // {{4 | square}}
  // you will get 16
  transform(inputValue: number, ...args: unknown[]): number {
    return inputValue * inputValue;
  }

}
