import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  apiUrl:string = "http://localhost:5555/employee/"

  constructor(private http: HttpClient) { }

  getEmployees() {
    return this.http.get(this.apiUrl);
  }

  createEmployee(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }
}
